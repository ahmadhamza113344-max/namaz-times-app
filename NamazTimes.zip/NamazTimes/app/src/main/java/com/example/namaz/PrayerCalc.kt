package com.example.namaz

import kotlin.math.*

/** نماز کے اوقات کا حساب (بغیر انٹرنیٹ)۔ طریقہ: کراچی، 18° فجر و عشاء۔ */
object PrayerCalc {
    private fun rad(d: Double) = Math.toRadians(d)
    private fun deg(r: Double) = Math.toDegrees(r)
    private fun fixAngle(a: Double) = a - 360.0 * floor(a / 360.0)
    private fun fixHour(h: Double) = h - 24.0 * floor(h / 24.0)

    private fun julian(year: Int, month: Int, day: Int): Double {
        var y = year
        var m = month
        if (m <= 2) { y -= 1; m += 12 }
        val a = floor(y / 100.0)
        val b = 2 - a + floor(a / 4)
        return floor(365.25 * (y + 4716)) + floor(30.6001 * (m + 1)) + day + b - 1524.5
    }

    /** returns (declination°, equation of time in hours) */
    private fun sun(jd: Double): Pair<Double, Double> {
        val d = jd - 2451545.0
        val g = rad(fixAngle(357.529 + 0.98560028 * d))
        val q = fixAngle(280.459 + 0.98564736 * d)
        val l = rad(fixAngle(q + 1.915 * sin(g) + 0.020 * sin(2 * g)))
        val e = rad(23.439 - 0.00000036 * d)
        val ra = fixHour(deg(atan2(cos(e) * sin(l), cos(l))) / 15.0)
        return Pair(deg(asin(sin(e) * sin(l))), q / 15.0 - ra)
    }

    /** [فجر, طلوع, ظہر, عصر, مغرب, عشاء] گھنٹوں میں؛ حساب نہ ہو سکے تو NaN */
    fun compute(
        year: Int, month: Int, day: Int,
        lat: Double, lng: Double, tzHours: Double,
        asrFactor: Double = 2.0,
        fajrAngle: Double = 18.0, ishaAngle: Double = 18.0
    ): DoubleArray {
        val jd = julian(year, month, day) - lng / (15.0 * 24.0)

        fun midDay(t: Double) = fixHour(12.0 - sun(jd + t).second)

        fun angleTime(angle: Double, t: Double, ccw: Boolean): Double {
            val decl = rad(sun(jd + t).first)
            val x = (-sin(rad(angle)) - sin(decl) * sin(rad(lat))) / (cos(decl) * cos(rad(lat)))
            if (x < -1.0 || x > 1.0) return Double.NaN
            val tt = deg(acos(x)) / 15.0
            return midDay(t) + if (ccw) -tt else tt
        }

        fun asrTime(t: Double): Double {
            val decl = rad(sun(jd + t).first)
            val a = -deg(atan(1.0 / (asrFactor + tan(abs(rad(lat) - decl)))))
            return angleTime(a, t, false)
        }

        val adj = tzHours - lng / 15.0
        val raw = doubleArrayOf(
            angleTime(fajrAngle, 5 / 24.0, true),
            angleTime(0.833, 6 / 24.0, true),
            midDay(12 / 24.0) + 1 / 60.0,
            asrTime(13 / 24.0),
            angleTime(0.833, 18 / 24.0, false),
            angleTime(ishaAngle, 18 / 24.0, false)
        )
        return DoubleArray(6) { fixHour(raw[it] + adj) }
    }
}
