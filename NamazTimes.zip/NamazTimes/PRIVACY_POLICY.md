# Privacy Policy – Awqat-e-Namaz

This app calculates prayer times on your device. It uses your approximate location (only if you tap "Use my location") to compute the times. Location data is never sent to any server, never shared, and never stored outside your device. The app has no ads, no analytics and no accounts.

Contact: <your email here>
