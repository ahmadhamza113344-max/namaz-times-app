package com.example.namaz

import android.Manifest
import android.content.Context
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalLayoutDirection
import java.util.Calendar
import java.util.TimeZone
import kotlin.math.floor

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Surface(Modifier.fillMaxSize()) { PrayerScreen() }
                }
            }
        }
    }
}

private val names = listOf("فجر", "طلوعِ آفتاب", "ظہر", "عصر", "مغرب", "عشاء")

private fun lastLocation(ctx: Context): Location? {
    val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    return try {
        lm.getProviders(true)
            .mapNotNull { provider -> lm.getLastKnownLocation(provider) }
            .filter { location ->
                val age = System.currentTimeMillis() - location.time
                age in 0..(12 * 60 * 60 * 1000L)
            }
            .maxByOrNull { it.time }
    } catch (e: SecurityException) {
        null
    }
}

private fun fmt(t: Double): String {
    if (t.isNaN()) return "--"
    val x = (t + 0.5 / 60.0) % 24.0
    val h = floor(x).toInt()
    val m = floor((x - h) * 60).toInt()
    val h12 = if (h % 12 == 0) 12 else h % 12
    return "%d:%02d %s".format(h12, m, if (h < 12) "AM" else "PM")
}

@Composable
fun PrayerScreen() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("namaz", Context.MODE_PRIVATE) }
    var lat by remember { mutableDoubleStateOf(prefs.getFloat("lat", 24.86f).toDouble()) }
    var lng by remember { mutableDoubleStateOf(prefs.getFloat("lng", 67.01f).toDouble()) }
    var hanafi by remember { mutableStateOf(prefs.getBoolean("hanafi", true)) }
    var status by remember { mutableStateOf("ابتدائی مقام: کراچی، پاکستان") }
    var showPrivacy by remember { mutableStateOf(false) }

    fun useDevice() {
        val l = lastLocation(ctx)
        if (l != null) {
            lat = l.latitude; lng = l.longitude
            prefs.edit().putFloat("lat", lat.toFloat()).putFloat("lng", lng.toFloat()).apply()
            status = "آپ کے مقام کے مطابق اوقات"
        } else {
            status = "مقام نہیں ملا۔ لوکیشن آن کر کے دوبارہ کوشش کریں"
        }
    }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) useDevice() else status = "اجازت نہیں ملی"
    }

    val now = Calendar.getInstance()
    val tz = TimeZone.getDefault().getOffset(now.timeInMillis) / 3600000.0
    val t = PrayerCalc.compute(
        now.get(Calendar.YEAR), now.get(Calendar.MONTH) + 1, now.get(Calendar.DAY_OF_MONTH),
        lat, lng, tz, if (hanafi) 2.0 else 1.0
    )
    val cur = now.get(Calendar.HOUR_OF_DAY) + now.get(Calendar.MINUTE) / 60.0
    val prayerIndices = listOf(0, 2, 3, 4, 5)
    val nextToday = prayerIndices.firstOrNull { t[it].isFinite() && t[it] > cur }
    val tomorrow = Calendar.getInstance().apply {
        timeInMillis = now.timeInMillis
        add(Calendar.DAY_OF_MONTH, 1)
    }
    val tomorrowTimes = if (nextToday == null) PrayerCalc.compute(
        tomorrow.get(Calendar.YEAR), tomorrow.get(Calendar.MONTH) + 1,
        tomorrow.get(Calendar.DAY_OF_MONTH), lat, lng, tz,
        if (hanafi) 2.0 else 1.0
    ) else null
    val next = nextToday ?: prayerIndices.firstOrNull { tomorrowTimes?.get(it)?.isFinite() == true }

    Column(
        Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("اوقاتِ نماز", fontSize = 28.sp, style = MaterialTheme.typography.headlineMedium)
        Text(status, style = MaterialTheme.typography.bodyMedium)
        Text("مقام: %.4f, %.4f".format(lat, lng), style = MaterialTheme.typography.bodySmall)
        if (nextToday == null && next != null) {
            Text("آج کے اوقات ختم ہو چکے ہیں؛ اگلی نماز کل ہوگی۔", style = MaterialTheme.typography.bodySmall)
        }

        for (i in names.indices) {
            val highlight = i == next
            Card(
                Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = if (highlight) MaterialTheme.colorScheme.primaryContainer
                    else MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(names[i], fontSize = 20.sp)
                    Text(fmt(t[i]), fontSize = 20.sp)
                }
            }
        }

        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween) {
            Text(if (hanafi) "عصر: حنفی" else "عصر: شافعی/مالکی/حنبلی")
            Switch(checked = hanafi, onCheckedChange = {
                hanafi = it
                prefs.edit().putBoolean("hanafi", it).apply()
            })
        }

        Button(onClick = { launcher.launch(Manifest.permission.ACCESS_COARSE_LOCATION) },
            modifier = Modifier.fillMaxWidth()) {
            Text("میرا مقام استعمال کریں")
        }
        Text("اوقات حساب سے نکالے جاتے ہیں، انٹرنیٹ درکار نہیں۔ مقامی مسجد کے مستند اوقات سے ضرور ملا لیں۔",
            style = MaterialTheme.typography.bodySmall)
        TextButton(onClick = { showPrivacy = true }) { Text("پرائیویسی پالیسی") }

        if (showPrivacy) {
            AlertDialog(
                onDismissRequest = { showPrivacy = false },
                confirmButton = { TextButton(onClick = { showPrivacy = false }) { Text("بند کریں") } },
                title = { Text("پرائیویسی پالیسی") },
                text = { Text("یہ ایپ نماز کے اوقات آپ کے آلے پر حساب کرتی ہے۔ آپ کی اجازت سے صرف تقریباً مقام (لوکیشن) حاصل کیا جاتا ہے تاکہ اوقات کا حساب ہو سکے۔ مقام کسی سرور پر نہیں بھیجا جاتا۔ اس ورژن میں اشتہارات، تجزیاتی ٹریکنگ یا صارف اکاؤنٹ شامل نہیں ہیں۔ رابطہ: ڈویلپر کا ای میل پلے اسٹور پر درج کیا جائے گا۔") }
            )
        }
    }
}
