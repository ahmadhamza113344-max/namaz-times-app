# اوقاتِ نماز – بنانے کا طریقہ

## 1. کھولیں
Android Studio (تازہ ورژن) میں File → Open → یہ فولڈر منتخب کریں۔ Gradle خود سیٹ اپ ہو جائے گا (انٹرنیٹ چاہیے)۔
اگر Studio اپڈیٹ کا کہے تو "Update" کر دیں۔

## 2. اپنا نام لگائیں
`app/build.gradle.kts` میں `applicationId` بدل کر اپنا منفرد نام رکھیں (مثلاً com.yourname.awqat)۔

## 3. APK (ٹیسٹ کے لیے)
Build → Build Bundle(s)/APK(s) → Build APK(s)

## 4. AAB (Play Store کے لیے)
Build → Generate Signed App Bundle / APK → Android App Bundle → Create new keystore
- keystore فائل اور پاسورڈ کی کئی کاپیاں محفوظ رکھیں۔ کھو گئی تو اپڈیٹ نہیں دے سکیں گے۔
- فائل بنے گی: app/release/app-release.aab

## 5. Play Console
- AAB اپلوڈ کریں
- PRIVACY_POLICY.md کو کسی ویب پیج پر رکھ کر اس کا لنک دیں
- Data safety فارم میں: Approximate location – صرف ڈیوائس پر، شیئر نہیں ہوتا
- Play کی تازہ ضرورت کے مطابق targetSdk چیک کر لیں

## نوٹ
- فی الحال کراچی طریقہ (18°) ہے۔ دوسرا طریقہ چاہیے تو `PrayerCalc.compute` میں زاویے بدلیں۔
- کوئی بھی چیز اپنی مسجد کے اوقات سے ملا لیں۔


## اشاعت سے پہلے لازمی کام (نومبر 2026)
- `applicationId` فی الحال `com.awqatenamaz.app` ہے؛ Play Console پر نئی ایپ بنانے سے پہلے اپنا دستیاب اور مستقل منفرد package ID منتخب کریں۔ پہلی اشاعت کے بعد اسے بدلنا عام طور پر ممکن نہیں ہوتا۔
- `PRIVACY_POLICY.md` میں حقیقی سپورٹ ای میل شامل کریں اور اسے عوامی HTTPS ویب صفحے پر شائع کریں۔ پالیسی کا لنک ایپ لسٹنگ اور Play Console میں درج کریں۔
- Play Console کے Data safety اور App content فارم اصل ایپ کے مطابق مکمل کریں۔
- نومبر 2026 میں نئی ایپس کے لیے target API 36 یا اس سے زیادہ درکار ہے؛ اس پروجیکٹ میں `targetSdk = 36` رکھا گیا ہے۔
- AAB کو اپنے ذاتی upload key سے sign کریں؛ keystore اور پاس ورڈ محفوظ رکھیں۔ کسی دوسرے شخص کو پاس ورڈ نہ دیں۔
- مختلف شہروں، تاریخوں، مقام کی اجازت منظور/رد ہونے، اور حنفی/غیر حنفی عصر کے اوقات کو مقامی مستند مسجد/معتبر تقویم سے ملا کر ٹیسٹ کریں۔
- موجودہ ZIP میں Gradle wrapper کی properties ہیں، مگر wrapper launcher/JAR شامل نہیں؛ Android Studio میں فولڈر کھول کر Gradle sync کریں۔ اس کام کے ماحول میں Android SDK/Gradle نصب نہ ہونے کی وجہ سے APK/AAB build کی تصدیق نہیں کی جا سکی۔

## صرف موبائل سے APK/AAB بلڈ (GitHub Actions)
1. GitHub پر اپنا اکاؤنٹ بنائیں یا سائن اِن کریں۔
2. اس ZIP کے اندر موجود `NamazTimes` فولڈر کی تمام فائلیں ایک نئے GitHub repository میں اپلوڈ کریں۔ `.github/workflows/android-build.yml` بھی ضرور شامل ہو۔
3. Repository میں Actions ٹیب کھولیں، `Android build` منتخب کریں، پھر `Run workflow` دبائیں۔
4. Build مکمل ہونے پر اسی run کے نیچے `Artifacts` سے `namaztimes-android-build` ZIP حاصل کریں۔ اس میں debug APK اور release AAB ہوں گے۔

اہم: یہ workflow موبائل کے براؤزر سے cloud build چلاتا ہے۔ Debug APK ٹیسٹنگ کے لیے ہے۔ Release AAB اس workflow میں ابھی unsigned ہے؛ Google Play پر اپلوڈ کرنے سے پہلے اپنی ذاتی upload key سے اسے sign کرنا اور حقیقی ڈیوائسز پر ٹیسٹ کرنا لازم ہے۔ اپنی keystore یا پاس ورڈ کسی کے ساتھ شیئر نہ کریں۔ GitHub پر فائل اپلوڈ کرنے کے لیے repository کی visibility اور ذاتی معلومات کا خیال رکھیں۔
